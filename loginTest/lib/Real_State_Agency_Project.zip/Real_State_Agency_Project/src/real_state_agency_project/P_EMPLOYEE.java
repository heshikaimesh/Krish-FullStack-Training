package real_state_agency_project;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class P_EMPLOYEE {

    private int id;
    private String firstName;
    private String lastName;
    private String phone;
    private String email;
    private String address;

    public int getId() {

        return id;

    }

    public void setId(int ID) {

        this.id = ID;

    }

    public String getFname() {

        return this.firstName;

    }

    public void setFname(String FNAME) {

        this.firstName = FNAME;

    }

    public String getLname() {

        return this.lastName;

    }

    public void setLname(String LNAME) {

        this.lastName = LNAME;

    }

    public String getPhone() {

        return this.phone;

    }

    public void setPhone(String PHONE) {

        this.phone = PHONE;

    }

    public String getEmail() {

        return this.email;

    }

    public void setEmail(String EMAIL) {

        this.email = EMAIL;

    }

    public String getAddress() {

        return this.address;

    }

    public void setAddress(String ADDRESS) {

        this.address = ADDRESS;

    }

    public P_EMPLOYEE() {
    }

    public P_EMPLOYEE(int ID, String FNAME, String LNAME, String PHONE, String EMAIL, String ADDRESS) {

        this.id = ID;
        this.firstName = FNAME;
        this.lastName = LNAME;
        this.phone = PHONE;
        this.email = EMAIL;
        this.address = ADDRESS;

    }

    //create a fuction to add a new employee
    //first create the owner in the databse
    public boolean addNewEmployee(P_EMPLOYEE employee) {

        PreparedStatement ps;

        String addQuery = "INSERT INTO `employee`(`fname`,`lname`,`phone`,`email`,`address`)VALUES(?,?,?,?,?)";

        
        try {
            ps = DBMS.getConnection().prepareStatement(addQuery);
            ps.setString(1, employee.getFname());
            
            ps.setString(2, employee.getLname());
            ps.setString(3, employee.getPhone());
            ps.setString(4, employee.getEmail());
            ps.setString(5, employee.getAddress());

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(P_EMPLOYEE.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    //create a function to edit the selected data 
    public boolean editEmployeeData(P_EMPLOYEE employee) {

        PreparedStatement ps;

        String editQuery = "UPDATE employee SET `fname`=?, `lname`=?, `phone`=?, `email`=?, `address`=? WHERE `id`=?";

        try {
            ps = DBMS.getConnection().prepareStatement(editQuery);
            ps.setString(1, employee.getFname());
            ps.setString(2, employee.getLname());
            ps.setString(3, employee.getPhone());
            ps.setString(4, employee.getEmail());
            ps.setString(5, employee.getAddress());
            ps.setInt(6, employee.getId());

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(P_EMPLOYEE.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    //create a function to delete the selected employee
    public boolean deleteEmployee(int employeeId) {

        PreparedStatement ps;

        String deleteQuery = "DELETE FROM `employee` WHERE `id`=?";

        try {
            ps = DBMS.getConnection().prepareStatement(deleteQuery);

            ps.setInt(1, employeeId);

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(P_EMPLOYEE.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    // create a function to return an arraylist of employee
    public ArrayList<P_EMPLOYEE> employeesList(){
    
        ArrayList<P_EMPLOYEE> list = new ArrayList<>();
        
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `employee`";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            P_EMPLOYEE employee;
            
            while (rs.next()) {
               
                employee = new P_EMPLOYEE(rs.getInt(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getString(4),
                                    rs.getString(5),
                                    rs.getString(6));
                
                list.add(employee);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(P_EMPLOYEE.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
 
}
