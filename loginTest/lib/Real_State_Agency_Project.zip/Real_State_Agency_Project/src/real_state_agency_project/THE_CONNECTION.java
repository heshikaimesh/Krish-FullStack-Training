package real_state_agency_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class THE_CONNECTION {
    public static Connection c;
    
  
        static{
            
        
        
    try {
        Class.forName("com.mysql.jdbc.Driver");
         c = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3307/java_rst_db","root","1234");
          
    
       }catch(Exception e){
          e.printStackTrace();
    
 }

 }


    public static void iud(String q) throws Exception{
        Statement s=  c.createStatement();
           s.executeUpdate(q);
         // int t =s.executeUpdate(q);
        //  System.out.println(t);
    }
    public static ResultSet search(String q )throws Exception{
         Statement s = c.createStatement();
        
            ResultSet rs = s.executeQuery(q);
            return rs;
    }
}

