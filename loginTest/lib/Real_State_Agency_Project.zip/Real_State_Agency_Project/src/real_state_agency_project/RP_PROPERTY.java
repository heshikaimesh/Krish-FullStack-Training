package real_state_agency_project;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class RP_PROPERTY {

    private int id;
    private int Ptype;
    
    private int size;
    private double monthly_Rental;
    private String address;
    private int floors;
    private int bedrooms;
    private int bathrooms;
    private int age;
    private boolean balcone;
    private boolean pool;
    private boolean backyard;
    private boolean garage;
    private String description;
    private boolean available;

    public RP_PROPERTY() {
    }
// 0, Ptype, Rtype, squareFeet, monthly_Rental, address, floors, bedrooms, bathrooms, age, haveBalcony, havePool, haveBackyard, haveGarage, description
    public RP_PROPERTY(int ID, int PTYPE, int SIZE, double MONTHLY_RENTAL, String ADDRESS, int FLOORS, int BEDROOMS, int BATHROOMS, int AGE, boolean BALCONE, boolean POOL, boolean BACKYARD, boolean GARAGE, String DESCRIPTION,  boolean AVAILABLE) {
        this.id = ID;
        this.Ptype = PTYPE;
        
        this.size = SIZE;
        this.monthly_Rental = MONTHLY_RENTAL;
        this.address = ADDRESS;
        this.floors = FLOORS;
        this.age = AGE;
        this.backyard = BACKYARD;
        this.bathrooms = BATHROOMS;
        this.bedrooms = BEDROOMS;
        this.description = DESCRIPTION;
        this.balcone = BALCONE;
        this.backyard = BACKYARD;
        this.garage = GARAGE;
        this.pool = POOL;
        this.available = AVAILABLE;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPtype() {
        return Ptype;
    }

    public void setPtype(int Ptype) {
        this.Ptype = Ptype;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public double getMonthly_Rental() {
        return monthly_Rental;
    }

    public void setMonthly_Rental(double monthly_Rental) {
        this.monthly_Rental = monthly_Rental;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getFloors() {
        return floors;
    }

    public void setFloors(int floors) {
        this.floors = floors;
    }

    public int getBedrooms() {
        return bedrooms;
    }

    public void setBedrooms(int bedrooms) {
        this.bedrooms = bedrooms;
    }

    public int getBathrooms() {
        return bathrooms;
    }

    public void setBathrooms(int bathrooms) {
        this.bathrooms = bathrooms;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean isBalcone() {
        return balcone;
    }

    public void setBalcone(boolean balcone) {
        this.balcone = balcone;
    }

    public boolean isPool() {
        return pool;
    }

    public void setPool(boolean pool) {
        this.pool = pool;
    }

    public boolean isBackyard() {
        return backyard;
    }

    public void setBackyard(boolean backyard) {
        this.backyard = backyard;
    }

    public boolean isGarage() {
        return garage;
    }

    public void setGarage(boolean garage) {
        this.garage = garage;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    
   

// create a fuction to add a new rental property
    public boolean addNewRentalProperty(RP_PROPERTY Rentalproperty) {

        PreparedStatement ps;

        // 0, Ptype, Rtype, squareFeet, monthly_Rental, address, floors, bedrooms, bathrooms, age, haveBalcony, havePool, haveBackyard, haveGarage, description
        String addQuery = "INSERT INTO `the_rental_property`(`ptype`, `square_feet`, `monthly_rental`, `address`, `floors`, `bedrooms`, `bathrooms`, `age`, `balcone`, `pool`, `backyard`, `garage`, `description`, `available`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        try {
            ps = DBMS.getConnection().prepareStatement(addQuery);
            ps.setInt(1, Rentalproperty.getPtype());
//            ps.setInt(2, Rentalproperty.getRtype());
            ps.setInt(2, Rentalproperty.getSize());
            ps.setDouble(3, Rentalproperty.getMonthly_Rental());
            ps.setString(4, Rentalproperty.getAddress());
            ps.setInt(5, Rentalproperty.getFloors());
            ps.setInt(6, Rentalproperty.getBedrooms());
            ps.setInt(7, Rentalproperty.getBathrooms());
            ps.setInt(8, Rentalproperty.getAge());
            ps.setBoolean(9, Rentalproperty.isBalcone());
            ps.setBoolean(10, Rentalproperty.isPool());
            ps.setBoolean(11, Rentalproperty.isBackyard());
            ps.setBoolean(12, Rentalproperty.isGarage());
            ps.setString(13, Rentalproperty.getDescription());
            ps.setBoolean(14, Rentalproperty.isAvailable());

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(RP_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    // create a fuction to edit a new  Rental property
    public boolean editRentalProperty(RP_PROPERTY Rentalproperty) {

        PreparedStatement ps;

        String editQuery = "UPDATE `the_rental_property` SET `ptype`=?, `square_feet`=?, `monthly_rental`=?, `address`=?, `floors`=?, `bedrooms`=?, `bathrooms`=?, `age`=?, `balcone`=?, `pool`=?, `backyard`=?, `garage`=?, `description`=?, `available`=? WHERE `id`=?";

        try {
            ps = DBMS.getConnection().prepareStatement(editQuery);
            ps.setInt(1, Rentalproperty.getPtype());
//            ps.setInt(2, Rentalproperty.getRtype());
            ps.setInt(2, Rentalproperty.getSize());
            ps.setDouble(3, Rentalproperty.getMonthly_Rental());
            ps.setString(4, Rentalproperty.getAddress());
            ps.setInt(5, Rentalproperty.getFloors());
            ps.setInt(6, Rentalproperty.getBedrooms());
            ps.setInt(7, Rentalproperty.getBathrooms());
            ps.setInt(8, Rentalproperty.getAge());
            ps.setBoolean(9, Rentalproperty.isBalcone());
            ps.setBoolean(10, Rentalproperty.isPool());
            ps.setBoolean(11, Rentalproperty.isBackyard());
            ps.setBoolean(12, Rentalproperty.isGarage());
            ps.setString(13, Rentalproperty.getDescription());
            ps.setBoolean(14, Rentalproperty.isAvailable());
            ps.setInt(15, Rentalproperty.getId());

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(RP_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    // create a fuction to delete a new Rental property
    public boolean removeRentalProperty(int RentalpropertyId) {

        
        PreparedStatement ps;

        String deleteQuery = "DELETE FROM `the_rental_property` WHERE `id`=?";

        try {
            ps = DBMS.getConnection().prepareStatement(deleteQuery);

            ps.setInt(1, RentalpropertyId);

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(RP_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    // create a fuction to search for a Rental property by id
    public RP_PROPERTY findRentalProperty(int RentalpropertyId) {

        PreparedStatement ps;
        ResultSet rs;
        RP_PROPERTY Rentalproperty = null;

        String searchQuery = "SELECT * FROM `the_rental_property` WHERE `id` = ?";

        try {

            ps = DBMS.getConnection().prepareStatement(searchQuery);
            ps.setInt(1, RentalpropertyId);
            rs = ps.executeQuery();

            if (rs.next()) {
                // `ptype`, `rtype`, `square_feet`, `monthly_rental`, `address`, `floors`, `bedrooms`, `bathrooms`, `age`, `balcone`, `pool`, `backyard`, `garage`, `description`
                Rentalproperty = new RP_PROPERTY(rs.getInt("id"),
                        rs.getInt("ptype"),
//                        rs.getInt("rtype"),
                        rs.getInt("square_feet"),
                        rs.getDouble("monthly_rental"),
                        rs.getString("address"),
                        rs.getInt("floors"),
                        rs.getInt("bedrooms"),
                        rs.getInt("bathrooms"),
                        rs.getInt("age"),
                        rs.getBoolean("balcone"),
                        rs.getBoolean("pool"),
                        rs.getBoolean("backyard"),
                        rs.getBoolean("garage"),
                        rs.getString("description"),
                        rs.getBoolean("available"));

            }

            return Rentalproperty;

        } catch (SQLException ex) {
            Logger.getLogger(RP_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
        }

        return Rentalproperty;
    }

    //create a function to return an arraylist of Rental properties
    public ArrayList<RP_PROPERTY> RentalpropertiesList() {

        ArrayList<RP_PROPERTY> list = new ArrayList<>();
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `the_rental_property`";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            RP_PROPERTY Rentalproperty;
            
            while (rs.next()) {
               
              Rentalproperty = new RP_PROPERTY(rs.getInt("id"),
                        rs.getInt("ptype"),
//                        rs.getInt("rtype"),
                        rs.getInt("square_feet"),
                        rs.getDouble("monthly_rental"),
                        rs.getString("address"),
                        rs.getInt("floors"),
                        rs.getInt("bedrooms"),
                        rs.getInt("bathrooms"),
                        rs.getInt("age"),
                        rs.getBoolean("balcone"),
                        rs.getBoolean("pool"),
                        rs.getBoolean("backyard"),
                        rs.getBoolean("garage"),
                        rs.getString("description"),
                        rs.getBoolean("available"));


                        
                list.add(Rentalproperty);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(RP_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
    
     //create a function to return an arraylist of Rental properties
    public ArrayList<RP_PROPERTY> AvailableRentalpropertiesList() {

        ArrayList<RP_PROPERTY> list = new ArrayList<>();
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `the_rental_property` WHERE `available`='1' ";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            RP_PROPERTY Rentalproperty;
            
            while (rs.next()) {
               
              Rentalproperty = new RP_PROPERTY(rs.getInt("id"),
                        rs.getInt("ptype"),
//                        rs.getInt("rtype"),
                        rs.getInt("square_feet"),
                        rs.getDouble("monthly_rental"),
                        rs.getString("address"),
                        rs.getInt("floors"),
                        rs.getInt("bedrooms"),
                        rs.getInt("bathrooms"),
                        rs.getInt("age"),
                        rs.getBoolean("balcone"),
                        rs.getBoolean("pool"),
                        rs.getBoolean("backyard"),
                        rs.getBoolean("garage"),
                        rs.getString("description"),
                        rs.getBoolean("available"));


                        
                list.add(Rentalproperty);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(RP_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
    
    //create a function to return an arraylist of Rental properties
    public ArrayList<RP_PROPERTY> UnavailableRentalpropertiesList() {

        ArrayList<RP_PROPERTY> list = new ArrayList<>();
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `the_rental_property` WHERE `available`='0' ";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            RP_PROPERTY Rentalproperty;
            
            while (rs.next()) {
               
              Rentalproperty = new RP_PROPERTY(rs.getInt("id"),
                        rs.getInt("ptype"),
//                        rs.getInt("rtype"),
                        rs.getInt("square_feet"),
                        rs.getDouble("monthly_rental"),
                        rs.getString("address"),
                        rs.getInt("floors"),
                        rs.getInt("bedrooms"),
                        rs.getInt("bathrooms"),
                        rs.getInt("age"),
                        rs.getBoolean("balcone"),
                        rs.getBoolean("pool"),
                        rs.getBoolean("backyard"),
                        rs.getBoolean("garage"),
                        rs.getString("description"),
                        rs.getBoolean("available"));


                        
                list.add(Rentalproperty);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(RP_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
 //----------------------------------------------------------------------------------------------------------------------
    // create a fuction to return a list of Rental property depending on the selected type
    //create a function to return an arraylist of Rental properties
    public ArrayList<RP_PROPERTY> propertiesListByType(int typeId) {

        ArrayList<RP_PROPERTY> list = new ArrayList<>();
        PreparedStatement ps;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `the_rental_property` WHERE `ptype`=?";
       
        try {
            ps = DBMS.getConnection().prepareStatement(selectQuery);
            ps.setInt(1, typeId);
            rs = ps.executeQuery();
        
            RP_PROPERTY property;
            
            while (rs.next()) {
               
                property = new RP_PROPERTY(rs.getInt("id"),
                       rs.getInt("ptype"),
//                        rs.getInt("rtype"),
                        rs.getInt("square_feet"),
                        rs.getDouble("monthly_rental"),
                        rs.getString("address"),
                        rs.getInt("floors"),
                        rs.getInt("bedrooms"),
                        rs.getInt("bathrooms"),
                        rs.getInt("age"),
                        rs.getBoolean("balcone"),
                        rs.getBoolean("pool"),
                        rs.getBoolean("backyard"),
                        rs.getBoolean("garage"),
                       rs.getString("description"),
                        rs.getBoolean("available"));

                        
                        
                list.add(property);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(RP_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
    
    
       //create a function to return an arraylist of owner properties
    public ArrayList<P_PROPERTY> propertiesListByOwner(int ownerId) {

        ArrayList<P_PROPERTY> list = new ArrayList<>();
        PreparedStatement ps;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `the_property` WHERE `ownerId`=?";
       
        try {
            ps = DBMS.getConnection().prepareStatement(selectQuery);
            ps.setInt(1, ownerId);
            rs = ps.executeQuery();
        
            P_PROPERTY property;
            
            while (rs.next()) {
               
                property = new P_PROPERTY(rs.getInt("id"),
                        rs.getInt("type"),
                        rs.getInt("square_feet"),
                        rs.getInt("ownerId"),
                        rs.getString("price"),
                        rs.getString("address"),
                        rs.getInt("bedrooms"),
                        rs.getInt("bathrooms"),
                        rs.getInt("age"),
                        rs.getBoolean("balcone"),
                        rs.getBoolean("pool"),
                        rs.getBoolean("backyard"),
                        rs.getBoolean("garage"),
                        rs.getString("description"));

                        
                        
                list.add(property);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(P_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
    
 
    // create a fuction to add a new property
    public boolean addImage(int propertyId, String the_image_path) {

        PreparedStatement ps;

        String addQuery = "INSERT INTO `property_images`(`property_id`,`the_image`) VALUES (?,?)";

        try {
            
            try {
                FileInputStream propertyImage = new FileInputStream(new File(the_image_path));
                ps = DBMS.getConnection().prepareStatement(addQuery);
                ps.setInt(1, propertyId);
                ps.setBinaryStream(2, propertyImage);
                
                return (ps.executeUpdate() > 0);
                
                
            } catch (FileNotFoundException ex) {
                //Logger.getLogger(P_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
                 JOptionPane.showMessageDialog(null, ex.getMessage() + " Invalid File ", "Image Error", 2);
                return false;
            }
           
        } catch (SQLException ex) {
            Logger.getLogger(P_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }
    
    // create a function to get the selected property images list
    public HashMap<byte[], Integer> propertyImagesList(int propertyId) {

        HashMap<byte[], Integer> list = new HashMap<>();
        PreparedStatement ps;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `property_images` WHERE `property_id`=?";
       
        try {
            ps = DBMS.getConnection().prepareStatement(selectQuery);
            ps.setInt(1, propertyId);
            rs = ps.executeQuery();
        
           
            
            while (rs.next()) {
       
                list.put(rs.getBytes("the_image"), rs.getInt("id"));
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(P_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
    
    
    // create a function to get image by id
    public byte[] getImageById(int imageId) {

        byte[] image;
        PreparedStatement ps;
        ResultSet rs;
        
        String selectQuery = "SELECT `the_image` FROM `property_images` WHERE `id`=?";
       
        try {
            ps = DBMS.getConnection().prepareStatement(selectQuery);
            ps.setInt(1, imageId);
            rs = ps.executeQuery();
        
           
            
            if (rs.next()) {
       
                return rs.getBytes("the_image");
                
            }else{
                
                return null;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(P_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        
        
    
    }
    
    
    // create a function to remove image by id
    public boolean removePropertyImage(int imageId) {

        byte[] image;
        PreparedStatement ps;
        ResultSet rs;
        
        String deleteQuery = "DELETE FROM `property_images` WHERE `id`=?";
       
        try {
            ps = DBMS.getConnection().prepareStatement(deleteQuery);
            ps.setInt(1, imageId);
            
            return (ps.executeUpdate() > 0);
            
        } catch (SQLException ex) {
            Logger.getLogger(P_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        
    
    }
    
    
}
