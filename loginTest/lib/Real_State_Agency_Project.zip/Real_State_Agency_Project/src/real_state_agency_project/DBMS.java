
package real_state_agency_project;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


public class DBMS {
     public static Connection c;
   
    private static String servername = "localhost";
    private static String dbname = "java_rst_db";
    private static String username = "root";
    private static Integer portnumber = 3307;
    private static String password = "1234";


public static Connection getConnection(){

Connection connection = null;
    MysqlDataSource datasource = new MysqlDataSource();
    
    datasource.setServerName(servername);
    datasource.setUser(username);
    datasource.setDatabaseName(dbname);
    datasource.setPortNumber(portnumber);
    datasource.setPassword(password);
     
        try {
            connection =  datasource.getConnection();
        } catch (SQLException ex) {
            Logger.getLogger(DBMS.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    return connection;
    
   
}
 public static ResultSet search(String q )throws Exception{
         Statement s = c.createStatement();
        
            ResultSet rs = s.executeQuery(q);
            return rs;
    }
}
