
package real_state_agency_project;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


public class P_SALE {
    
    private int id;
    private int propertyId;
    private int clientId;
    private boolean paid;
    private String finalPrice;
    private String sellingDate;
    
    public P_SALE(){}
    
    public P_SALE(int ID, int PROPERTY_ID, int CLIENT_ID, String FINAL_PRICE, boolean PAID, String SELLING_DATE){
    
        this.id = ID;
        this.propertyId = PROPERTY_ID;
        this.clientId  = CLIENT_ID;
        this.finalPrice = FINAL_PRICE;
        this.paid = PAID;
        this.sellingDate = SELLING_DATE;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(int propertyId) {
        this.propertyId = propertyId;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public boolean isPaid() {
        return paid;
    }

    public void setPaid(boolean paid) {
        this.paid = paid;
    }

    public String getFinalPrice() {
        return finalPrice;
    }

    public void setFinalPrice(String finalPrice) {
        this.finalPrice = finalPrice;
    }

    public String getSellingDate() {
        return sellingDate;
    }

    public void setSellingDate(String sellingDate) {
        this.sellingDate = sellingDate;
    }

    

    
    //create a fuction to add a new client
    
    public boolean addNewSale(P_SALE sale) {

        PreparedStatement ps;

        String addQuery = "INSERT INTO `sale`(`property_id`,`client_id`,`final_price`, `paid`,`sale_date`) VALUES(?,?,?,?,?)";

        
        try {
            ps = DBMS.getConnection().prepareStatement(addQuery);
            
            ps.setInt(1, sale.getPropertyId());
            ps.setInt(2, sale.getClientId());
            ps.setString(3, sale.getFinalPrice());
            ps.setBoolean(4, sale.isPaid());
            ps.setString(5, sale.getSellingDate());
            

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(P_SALE.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    //create a function to edit the selected data 
    public boolean editSale(P_SALE sale) {

        PreparedStatement ps;

        String editQuery = "UPDATE sale SET `property_id`=?, `client_id`=?, `final_price`=?, `paid`=?, `sale_date`=?  WHERE `id`=?";

        try {
            ps = DBMS.getConnection().prepareStatement(editQuery);
            
            ps.setInt(1, sale.getPropertyId());
            ps.setInt(2, sale.getClientId());
            ps.setString(3, sale.getFinalPrice());
            ps.setBoolean(4, sale.isPaid());
            ps.setString(5, sale.getSellingDate());
            
            ps.setInt(6, sale.getId());

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(P_SALE.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    //create a function to delete the selected sale
    public boolean deleteSale(int saleId) {

        PreparedStatement ps;

        String deleteQuery = "DELETE FROM `sale` WHERE `id`=?";

        try {
            ps = DBMS.getConnection().prepareStatement(deleteQuery);

            ps.setInt(1, saleId);

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(P_SALE.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }
    
    
    // create a function to return an arraylist of sales
    public ArrayList<P_SALE> salesList(){
    
        ArrayList<P_SALE> list = new ArrayList<>();
        
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `sale`";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            P_SALE sale;
            
            while (rs.next()) {
               
                sale = new P_SALE(rs.getInt(1),
                                    rs.getInt(2),
                                    rs.getInt(3),
                                    rs.getString(4),
                                    rs.getBoolean(5),
                                    rs.getString(6));
                                    
                
                list.add(sale);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(P_SALE.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
     public ArrayList<P_SALE> UnpaidsalesList(){
    
        ArrayList<P_SALE> list = new ArrayList<>();
        
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `sale` WHERE `paid`='0'";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            P_SALE sale;
            
            while (rs.next()) {
               
                sale = new P_SALE(rs.getInt(1),
                                    rs.getInt(2),
                                    rs.getInt(3),
                                    rs.getString(4),
                                    rs.getBoolean(5),
                                    rs.getString(6));
                                    
                
                list.add(sale);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(P_SALE.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
      public ArrayList<P_SALE> PaidsalesList(){
    
        ArrayList<P_SALE> list = new ArrayList<>();
        
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `sale` WHERE `paid` = '1'";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            P_SALE sale;
            
            while (rs.next()) {
               
                sale = new P_SALE(rs.getInt(1),
                                    rs.getInt(2),
                                    rs.getInt(3),
                                    rs.getString(4),
                                    rs.getBoolean(5),
                                    rs.getString(6));
                                    
                
                list.add(sale);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(P_SALE.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
    
     public ArrayList<P_SALE> propertiesUnpaidList() {

        ArrayList<P_SALE> list = new ArrayList<>();
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `sale` WHERE `paid` = '0' ";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            P_SALE property;
            
            while (rs.next()) {
               
                property = new P_SALE(rs.getInt("id"),
                                    rs.getInt("property_id"),
                                    rs.getInt("client_id"),
                                    rs.getString("final_price"),
                                    rs.getBoolean("paid"),
                                    rs.getString("sale_date"));
                        
                        
                list.add(property);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(P_SALE.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
     
     public P_SALE findCompanyProperty(int CustomerpropertyId) {

        PreparedStatement ps;
        ResultSet rs;
        P_SALE Customerproperty = null;

        String searchQuery = "SELECT * FROM `sale` WHERE `id` = ?";

        try {

            ps = DBMS.getConnection().prepareStatement(searchQuery);
            ps.setInt(1, CustomerpropertyId);
            rs = ps.executeQuery();

            if (rs.next()) {

               
           Customerproperty = new  P_SALE(rs.getInt("id"),
                                    rs.getInt("property_id"),
                                    rs.getInt("client_id"),
                                    rs.getString("final_price"),
                                    rs.getBoolean("paid"),
                                    rs.getString("sale_date"));
            }

            return Customerproperty;

        } catch (SQLException ex) {
            Logger.getLogger(P_SALE.class.getName()).log(Level.SEVERE, null, ex);
        }

        return Customerproperty;
    }
     
     public ArrayList<P_SALE> propertiesListPaid() {

        ArrayList<P_SALE> list = new ArrayList<>();
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `sale` WHERE `paid` = '1' ";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            P_SALE property;
            
            while (rs.next()) {
               
                property = new P_SALE(rs.getInt("id"),
                                    rs.getInt("property_id"),
                                    rs.getInt("client_id"),
                                    rs.getString("final_price"),
                                    rs.getBoolean("paid"),
                                    rs.getString("sale_date"));
                        
                        
                list.add(property);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(P_SALE.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
     
      public ArrayList<P_SALE> propertiesList() {

        ArrayList<P_SALE> list = new ArrayList<>();
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `sale` ";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            P_SALE property;
            
            while (rs.next()) {
               
                property = new P_SALE(rs.getInt("id"),
                                    rs.getInt("property_id"),
                                    rs.getInt("client_id"),
                                    rs.getString("final_price"),
                                    rs.getBoolean("paid"),
                                    rs.getString("sale_date"));
                        
                        
                list.add(property);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(P_SALE.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }


}
