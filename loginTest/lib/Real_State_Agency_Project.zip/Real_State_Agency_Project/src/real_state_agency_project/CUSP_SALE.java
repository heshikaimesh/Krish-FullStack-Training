
package real_state_agency_project;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class CUSP_SALE {
    
    private int id;
    private int propertyId;
    private int clientId;
    private int ownerId;
    private String finalPrice;
    private double commision;
    private double commision_amount;
    private boolean paid;
    private String sellingDate;
    
    public CUSP_SALE(){}
    
    public CUSP_SALE(int ID, int PROPERTY_ID, int OWNER_ID, int CLIENT_ID, String FINAL_PRICE, double COMMISION,  double COMMISION_AMOUNT,  boolean PAID, String SELLING_DATE){
    
        this.id = ID;
        this.propertyId = PROPERTY_ID;
        this.clientId  = CLIENT_ID;
        this.ownerId  = OWNER_ID;
        this.finalPrice = FINAL_PRICE;
        this.commision = COMMISION;
        this.commision_amount = COMMISION_AMOUNT;
        this.paid = PAID;
        this.sellingDate = SELLING_DATE;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(int propertyId) {
        this.propertyId = propertyId;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public int getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(int ownerId) {
        this.ownerId = ownerId;
    }

    public String getFinalPrice() {
        return finalPrice;
    }

    public void setFinalPrice(String finalPrice) {
        this.finalPrice = finalPrice;
    }

    public double getCommision() {
        return commision;
    }

    public void setCommision(double commision) {
        this.commision = commision;
    }

    public double getCommision_amount() {
        return commision_amount;
    }

    public void setCommision_amount(double commision_amount) {
        this.commision_amount = commision_amount;
    }

    public boolean isPaid() {
        return paid;
    }

    public void setPaid(boolean paid) {
        this.paid = paid;
    }

    public String getSellingDate() {
        return sellingDate;
    }

    public void setSellingDate(String sellingDate) {
        this.sellingDate = sellingDate;
    }

   
    
    //create a fuction to add a new client
    
    public boolean addNewCustomerPropertySale(CUSP_SALE sale) {

        PreparedStatement ps;

        String addQuery = "INSERT INTO `customer_property_sale`(`property_id`, `owner_id`, `client_id`, `final_price`, `commision`, `commision_amount`, `paid`, `sale_date`) VALUES(?,?,?,?,?,?,?,?)";

        
        try {
            ps = DBMS.getConnection().prepareStatement(addQuery);
            
            ps.setInt(1, sale.getPropertyId());
            ps.setInt(2, sale.getOwnerId());
            ps.setInt(3, sale.getClientId());
            ps.setString(4, sale.getFinalPrice());
            ps.setDouble(5, sale.getCommision());
            ps.setDouble(6, sale.getCommision_amount());
            ps.setBoolean(7, sale.isPaid());
            ps.setString(8, sale.getSellingDate());
            

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(CUSP_SALE.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    //create a function to edit the selected data 
    public boolean editCustomerPropertySale(CUSP_SALE sale) {

        PreparedStatement ps;

        String editQuery = "UPDATE customer_property_sale SET `property_id`=?, `owner_id`=?, `client_id`=?, `final_price`=?, `commision`=?, `commision_amount`=?, `paid`=?, `sale_date`=?  WHERE `id`=?";

        try {
            ps = DBMS.getConnection().prepareStatement(editQuery);
            
            ps.setInt(1, sale.getPropertyId());
            ps.setInt(2, sale.getOwnerId());
            ps.setInt(3, sale.getClientId());
            ps.setString(4, sale.getFinalPrice());
            ps.setDouble(5, sale.getCommision());
            ps.setDouble(6, sale.getCommision_amount());
            ps.setBoolean(7, sale.isPaid());
            ps.setString(8, sale.getSellingDate());
            ps.setInt(9, sale.getId());

            
            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(CUSP_SALE.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    //create a function to delete the selected sale
    public boolean deleteCustomerPropertySale(int saleId) {

        PreparedStatement ps;

        String deleteQuery = "DELETE FROM `customer_property_sale` WHERE `id`=?";

        try {
            ps = DBMS.getConnection().prepareStatement(deleteQuery);

            ps.setInt(1, saleId);

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(CUSP_SALE.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }
    
    
    // create a function to return an arraylist of sales
    public ArrayList<CUSP_SALE> salesList(){
    
        ArrayList<CUSP_SALE> list = new ArrayList<>();
        
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `customer_property_sale`";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            CUSP_SALE sale;
            
            while (rs.next()) {
               
                sale = new CUSP_SALE(rs.getInt(1),
                                    rs.getInt(2),
                                    rs.getInt(3),
                                    rs.getInt(4),
                                    rs.getString(5),
                                    rs.getDouble(6),
                                    rs.getDouble(7),
                                    rs.getBoolean(8),
                                    rs.getString(9));
                                    
                
                list.add(sale);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(CUSP_SALE.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
    
    
        // create a fuction to search for a property by id
    public CUSP_SALE findCustomerProperty(int CustomerpropertyId) {

        PreparedStatement ps;
        ResultSet rs;
        CUSP_SALE Customerproperty = null;

        String searchQuery = "SELECT * FROM `customer_property_sale` WHERE `id` = ?";

        try {

            ps = DBMS.getConnection().prepareStatement(searchQuery);
            ps.setInt(1, CustomerpropertyId);
            rs = ps.executeQuery();

            if (rs.next()) {

               
           Customerproperty = new  CUSP_SALE(rs.getInt("id"),
                                    rs.getInt("property_id"),
                                    rs.getInt("owner_id"),
                                    rs.getInt("client_id"),
                                    rs.getString("final_price"),
                                    rs.getDouble("commision"),
                                    rs.getDouble("commision_amount"),
                                    rs.getBoolean("paid"),
                                    rs.getString("sale_date"));
            }

            return Customerproperty;

        } catch (SQLException ex) {
            Logger.getLogger(CUSP_SALE.class.getName()).log(Level.SEVERE, null, ex);
        }

        return Customerproperty;
    }
    
     public ArrayList<CUSP_SALE> propertiesList() {

        ArrayList<CUSP_SALE> list = new ArrayList<>();
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `customer_property_sale`";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            CUSP_SALE property;
            
            while (rs.next()) {
               
                property = new CUSP_SALE(rs.getInt("id"),
                                    rs.getInt("property_id"),
                                    rs.getInt("owner_id"),
                                    rs.getInt("client_id"),
                                    rs.getString("final_price"),
                                    rs.getDouble("commision"),
                                    rs.getDouble("commision_amount"),
                                    rs.getBoolean("paid"),
                                    rs.getString("sale_date"));
                        
                        
                list.add(property);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(CUSP_SALE.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
      public ArrayList<CUSP_SALE> propertiesUnpaidList() {

        ArrayList<CUSP_SALE> list = new ArrayList<>();
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `customer_property_sale` WHERE `paid` = '0' ";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            CUSP_SALE property;
            
            while (rs.next()) {
               
                property = new CUSP_SALE(rs.getInt("id"),
                                   rs.getInt("property_id"),
                                    rs.getInt("owner_id"),
                                    rs.getInt("client_id"),
                                    rs.getString("final_price"),
                                    rs.getDouble("commision"),
                                    rs.getDouble("commision_amount"),
                                    rs.getBoolean("paid"),
                                    rs.getString("sale_date"));
                        
                        
                        
                        
                list.add(property);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(CUSP_SALE.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
       public ArrayList<CUSP_SALE> propertiesListPaid() {

        ArrayList<CUSP_SALE> list = new ArrayList<>();
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `customer_property_sale` WHERE `paid` = '1' ";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            CUSP_SALE property;
            
            while (rs.next()) {
               
                property = new CUSP_SALE(rs.getInt("id"),
                                    rs.getInt("property_id"),
                                    rs.getInt("owner_id"),
                                    rs.getInt("client_id"),
                                    rs.getString("final_price"),
                                    rs.getDouble("commision"),
                                    rs.getDouble("commision_amount"),
                                    rs.getBoolean("paid"),
                                    rs.getString("sale_date"));
                        
                        
                        
                list.add(property);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(CUSP_SALE.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
    
}
