/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package real_state_agency_project;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 *
 * @author Ahsika
 */
public class Log {
    public Logger logger;
    FileHandler fh;
    
    public Log(String file_name) throws SecurityException, IOException{
        File f = new File(file_name);
        if(!f.exists()){
            f.createNewFile();
        }
        
        fh = new FileHandler(file_name,true);
        logger = logger.getLogger("test");
        logger.addHandler(fh);
        SimpleFormatter formatter = new SimpleFormatter();
        fh.setFormatter(formatter);
    }
    
}
