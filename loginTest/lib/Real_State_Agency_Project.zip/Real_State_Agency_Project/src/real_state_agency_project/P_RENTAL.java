
package real_state_agency_project;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class P_RENTAL {
    
    private int id;
    //private int rental_type;
    private int clientId;
    private int rental_propertyId;
    private int months;
    private String monthly_rental;
    private int lawyerId;
    private String amount_payable;
    private boolean paid;
    private String start_date;
    private String end_date;
    
    
    public P_RENTAL(){}
    
    public P_RENTAL(int ID, int CLIENT_ID, int RENTAL_PROPERTY_ID, int MONTHS, String MONTHLY_RENTAL, int LAWYER_ID, String AMOUNT_PAYABLE, String START_DATE, String END_DATE, boolean PAID){
    
        this.id = ID;
        //this.rental_type = RENTAL_TYPE;
        this.clientId  = CLIENT_ID;
        this.rental_propertyId  = RENTAL_PROPERTY_ID;
        this.months  = MONTHS;
        this.monthly_rental  = MONTHLY_RENTAL;
        this.lawyerId  = LAWYER_ID;
        this.amount_payable  = AMOUNT_PAYABLE;
        this.start_date = START_DATE;
        this.end_date = END_DATE;
        this.paid = PAID;
        
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public int getRental_propertyId() {
        return rental_propertyId;
    }

    public void setRental_propertyId(int rental_propertyId) {
        this.rental_propertyId = rental_propertyId;
    }

    public int getMonths() {
        return months;
    }

    public void setMonths(int months) {
        this.months = months;
    }

    public String getMonthly_rental() {
        return monthly_rental;
    }

    public void setMonthly_rental(String monthly_rental) {
        this.monthly_rental = monthly_rental;
    }

    public int getLawyerId() {
        return lawyerId;
    }

    public void setLawyerId(int lawyerId) {
        this.lawyerId = lawyerId;
    }

    public String getAmount_payable() {
        return amount_payable;
    }

    public void setAmount_payable(String amount_payable) {
        this.amount_payable = amount_payable;
    }

    public boolean isPaid() {
        return paid;
    }

    public void setPaid(boolean paid) {
        this.paid = paid;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    
    
    //create a fuction to add a new rental
    
    public boolean addNewRent(P_RENTAL rental) {

        PreparedStatement ps;

        String addQuery = "INSERT INTO `rental`(`clientId`,`rental_propertyId`,`months`,`monthly_rental`,`lawyerId`,`amount_payable`,`start_date`,`end_date`,`paid`) VALUES(?,?,?,?,?,?,?,?,?)";

        
        try {
            ps = DBMS.getConnection().prepareStatement(addQuery);
            
            //ps.setInt(1, rental.getRental_type());
            ps.setInt(1, rental.getClientId());
            ps.setInt(2, rental.getRental_propertyId());
            ps.setInt(3, rental.getMonths());
            ps.setString(4, rental.getMonthly_rental());
            ps.setInt(5, rental.getLawyerId());
            ps.setString(6, rental.getAmount_payable());
            ps.setString(7, rental.getStart_date());
            ps.setString(8, rental.getEnd_date());
            ps.setBoolean(9, rental.isPaid());
            
            

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(P_RENTAL.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    //create a function to edit the selected data 
    public boolean editRental(P_RENTAL rental) {

        PreparedStatement ps;

        String editQuery = "UPDATE rental SET `clientId`=?,`rental_propertyId`=?,`months`=?,`monthly_rental`=?,`lawyerId`=?,`amount_payable`=?,`start_date`=?,`end_date`=?,`paid`=? WHERE `id`=?";

        try {
            ps = DBMS.getConnection().prepareStatement(editQuery);
            
           // ps.setInt(1, rental.getRental_type());
            ps.setInt(1, rental.getClientId());
            ps.setInt(2, rental.getRental_propertyId());
            ps.setInt(3, rental.getMonths());
            ps.setString(4, rental.getMonthly_rental());
            ps.setInt(5, rental.getLawyerId());
            ps.setString(6, rental.getAmount_payable());
            ps.setString(7, rental.getStart_date());
            ps.setString(8, rental.getEnd_date());
            ps.setBoolean(9, rental.isPaid());
            ps.setInt(10, rental.getId());
            
            

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(P_RENTAL.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    //create a function to delete the selected rental
    public boolean deleteRental(int rentalId) {

        PreparedStatement ps;

        String deleteQuery = "DELETE FROM `rental` WHERE `id`=?";

        try {
            ps = DBMS.getConnection().prepareStatement(deleteQuery);

            ps.setInt(1, rentalId);

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(P_RENTAL.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }
    
    
    // create a function to return an arraylist of sales
    public ArrayList<P_RENTAL> rentalsList(){
    
        ArrayList<P_RENTAL> list = new ArrayList<>();
        
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `rental`";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            P_RENTAL rental;
            
            while (rs.next()) {
               
                rental = new P_RENTAL(rs.getInt(1),
                                    
                                    rs.getInt(2),
                                    rs.getInt(3),
                                    rs.getInt(4),
                                    rs.getString(5),
                                    rs.getInt(6),
                                    rs.getString(7),
                                    rs.getString(8),
                                    rs.getString(9),
                                    rs.getBoolean(10));
                                    
                
                list.add(rental);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(P_RENTAL.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
    
    // create a fuction to search for a rental by id
    public P_RENTAL findRental(int rentalId) {

        PreparedStatement ps;
        ResultSet rs;
        P_RENTAL rental = null;

        String searchQuery = "SELECT * FROM `rental` WHERE `id` = ?";

        try {

            ps = DBMS.getConnection().prepareStatement(searchQuery);
            ps.setInt(1, rentalId);
            rs = ps.executeQuery();

            if (rs.next()) {
                
              rental = new P_RENTAL(rs.getInt(1),
                                    rs.getInt(2),
                                    rs.getInt(3),
                                    rs.getInt(4),
                                    rs.getString(5),
                                    rs.getInt(6),
                                    rs.getString(7),
                                    rs.getString(8),
                                    rs.getString(9),
                                    rs.getBoolean(10));
                                    

            }

            return rental;

        } catch (SQLException ex) {
            Logger.getLogger(P_RENTAL.class.getName()).log(Level.SEVERE, null, ex);
        }

        return rental;
    }
    
    
 
    
    //---------------------------------
    
     // create a fuction to return a list of property depending on the selected type
    //create a function to return an arraylist of properties
    public ArrayList<P_PROPERTY> propertiesListByType(int typeId) {

        ArrayList<P_PROPERTY> list = new ArrayList<>();
        PreparedStatement ps;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `the_property` WHERE `type`=?";
       
        try {
            ps = DBMS.getConnection().prepareStatement(selectQuery);
            ps.setInt(1, typeId);
            rs = ps.executeQuery();
        
            P_PROPERTY property;
            
            while (rs.next()) {
               
                property = new P_PROPERTY(rs.getInt("id"),
                        rs.getInt("type"),
                        rs.getInt("square_feet"),
                        rs.getInt("ownerId"),
                        rs.getString("price"),
                        rs.getString("address"),
                        rs.getInt("bedrooms"),
                        rs.getInt("bathrooms"),
                        rs.getInt("age"),
                        rs.getBoolean("balcone"),
                        rs.getBoolean("pool"),
                        rs.getBoolean("backyard"),
                        rs.getBoolean("garage"),
                        rs.getString("description"));

                        
                        
                list.add(property);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(P_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
    
    
       //create a function to return an arraylist of owner properties
    public ArrayList<P_PROPERTY> propertiesListByOwner(int ownerId) {

        ArrayList<P_PROPERTY> list = new ArrayList<>();
        PreparedStatement ps;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `the_property` WHERE `ownerId`=?";
       
        try {
            ps = DBMS.getConnection().prepareStatement(selectQuery);
            ps.setInt(1, ownerId);
            rs = ps.executeQuery();
        
            P_PROPERTY property;
            
            while (rs.next()) {
               
                property = new P_PROPERTY(rs.getInt("id"),
                        rs.getInt("type"),
                        rs.getInt("square_feet"),
                        rs.getInt("ownerId"),
                        rs.getString("price"),
                        rs.getString("address"),
                        rs.getInt("bedrooms"),
                        rs.getInt("bathrooms"),
                        rs.getInt("age"),
                        rs.getBoolean("balcone"),
                        rs.getBoolean("pool"),
                        rs.getBoolean("backyard"),
                        rs.getBoolean("garage"),
                        rs.getString("description"));

                        
                        
                list.add(property);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(P_PROPERTY.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
    
 
        
    
}

    


