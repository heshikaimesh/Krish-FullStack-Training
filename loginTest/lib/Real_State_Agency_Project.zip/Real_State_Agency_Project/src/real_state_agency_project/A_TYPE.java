package real_state_agency_project;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class A_TYPE {

    private int id;
    private String province;
    private String district;

    //create the getes and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    
    
    //create the class constructors
    public A_TYPE() {
    }

    public A_TYPE(Integer ID, String PROVINCE, String DISTRICT) {

        this.id = ID;
        this.province = PROVINCE;
        this.district = DISTRICT;
    }

    //create a function to insert - edit - remove type
    public boolean execTypeQuery(String queryType, A_TYPE type) {

        PreparedStatement ps;

        //add new type
        if (queryType.equals("add")) {

            try {
                ps = DBMS.getConnection().prepareStatement("INSERT INTO `area`(`province`,`district`)VALUES (?,?)");
                ps.setString(1, type.getProvince());
                ps.setString(2, type.getDistrict());

                return (ps.executeUpdate() > 0);

            } catch (SQLException ex) {
                Logger.getLogger(A_TYPE.class.getName()).log(Level.SEVERE, null, ex);
                return false;
            }

        } //query - > UPDATE `property_type` SET `name`=?,`description`=? WHERE `id` = ?
        else if (queryType.equals("edit")) {

            try {
                ps = DBMS.getConnection().prepareStatement("UPDATE `area` SET `province`=?,`district`=? WHERE `id` = ?");
                ps.setString(1, type.getProvince());
                ps.setString(2, type.getDistrict());
                ps.setInt(3, type.getId());

                return (ps.executeUpdate() > 0);

            } catch (SQLException ex) {
                Logger.getLogger(A_TYPE.class.getName()).log(Level.SEVERE, null, ex);
                return false;
            }

        } //Query -> DELETE FROM `property_type` WHERE `id`=?
        else if (queryType.equals("remove")) {

            try {
                ps = DBMS.getConnection().prepareStatement("DELETE FROM `area` WHERE `id`=?");
                ps.setInt(1, type.getId());

                return (ps.executeUpdate() > 0);

            } catch (SQLException ex) {
                Logger.getLogger(A_TYPE.class.getName()).log(Level.SEVERE, null, ex);
                return false;
            }

        } else {
            JOptionPane.showMessageDialog(null, "Enter The Correct Query( add,edit,remove)", "Invalid Operation", 2);
            return false;
        }
    }

    //create a function to returnlist of alltypes in a hashmap
    // string is the key
    // integer is the value
     public HashMap<String, Integer> getTypeMap() {

        HashMap<String, Integer> map = new HashMap<>();

        Statement st;
        ResultSet rs;

        try {

            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery("SELECT * FROM `area`");

            A_TYPE type;

            while (rs.next()) {

                type = new A_TYPE(rs.getInt(1), rs.getString(2), rs.getString(3));

                map.put(type.getDistrict(), type.getId());
            }

        } catch (SQLException ex) {
            Logger.getLogger(A_TYPE.class.getName()).log(Level.SEVERE, null, ex);
        }

        return map;
        
    }
    
    //create a function to get the type data by id
    //we can use getTypesMap() fuction to get the id and name
    //but we want the description to
    
    public A_TYPE getTypeById(Integer id){
    
        PreparedStatement ps;
        ResultSet rs;
        
        A_TYPE type = new A_TYPE();

        try {
 
           ps = DBMS.getConnection().prepareStatement("SELECT * FROM `area` WHERE `id`=?");
           ps.setInt(1, id);
           rs = ps.executeQuery();
           
          
           if(rs.next()){
           
               type.setId(id);
               type.setProvince(rs.getString(2));
               type.setDistrict(rs.getString(3));
               
           }
           
        
        } catch (SQLException ex) {
            Logger.getLogger(A_TYPE.class.getName()).log(Level.SEVERE, null, ex);
        }
        return type;
    }
    
    
     public ArrayList<A_TYPE> areaList(){
    
        ArrayList<A_TYPE> list = new ArrayList<>();
        
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `area`";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            A_TYPE area;
            
            while (rs.next()) {
               
                area = new A_TYPE(rs.getInt(1),
                                    rs.getString(2),
                                    rs.getString(3));
                
                list.add(area);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(A_TYPE.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
 
    
}
