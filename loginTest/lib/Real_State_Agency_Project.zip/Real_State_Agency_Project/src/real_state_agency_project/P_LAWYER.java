package real_state_agency_project;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class P_LAWYER {

    private int id;
    private String firstName;
    private String lastName;
    private String phone;
    private String email;
    private String address;

    public int getId() {

        return id;

    }

    public void setId(int ID) {

        this.id = ID;

    }

    public String getFname() {

        return this.firstName;

    }

    public void setFname(String FNAME) {

        this.firstName = FNAME;

    }

    public String getLname() {

        return this.lastName;

    }

    public void setLname(String LNAME) {

        this.lastName = LNAME;

    }

    public String getPhone() {

        return this.phone;

    }

    public void setPhone(String PHONE) {

        this.phone = PHONE;

    }

    public String getEmail() {

        return this.email;

    }

    public void setEmail(String EMAIL) {

        this.email = EMAIL;

    }

    public String getAddress() {

        return this.address;

    }

    public void setAddress(String ADDRESS) {

        this.address = ADDRESS;

    }

    public P_LAWYER() {
    }

    public P_LAWYER(int ID, String FNAME, String LNAME, String PHONE, String EMAIL, String ADDRESS) {

        this.id = ID;
        this.firstName = FNAME;
        this.lastName = LNAME;
        this.phone = PHONE;
        this.email = EMAIL;
        this.address = ADDRESS;

    }

    //create a fuction to add a new lawyer
    //first create the lawyer in the databse
    public boolean addNewLawyer(P_LAWYER lawyer) {

        PreparedStatement ps;

        String addQuery = "INSERT INTO `lawyer`(`fname`,`lname`,`phone`,`email`,`address`)VALUES(?,?,?,?,?)";

        
        try {
            ps = DBMS.getConnection().prepareStatement(addQuery);
            ps.setString(1, lawyer.getFname());
            
            ps.setString(2, lawyer.getLname());
            ps.setString(3, lawyer.getPhone());
            ps.setString(4, lawyer.getEmail());
            ps.setString(5, lawyer.getAddress());

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(P_LAWYER.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    //create a function to edit the selected data 
    public boolean editLawyerData(P_LAWYER lawyer) {

        PreparedStatement ps;

        String editQuery = "UPDATE lawyer SET `fname`=?, `lname`=?, `phone`=?, `email`=?, `address`=? WHERE `id`=?";

        try {
            ps = DBMS.getConnection().prepareStatement(editQuery);
            ps.setString(1, lawyer.getFname());
            ps.setString(2, lawyer.getLname());
            ps.setString(3, lawyer.getPhone());
            ps.setString(4, lawyer.getEmail());
            ps.setString(5, lawyer.getAddress());
            ps.setInt(6, lawyer.getId());

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(P_LAWYER.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    //create a function to delete the selected lawyer
    public boolean deleteLawyer(int lawyerId) {

        PreparedStatement ps;

        String deleteQuery = "DELETE FROM `lawyer` WHERE `id`=?";

        try {
            ps = DBMS.getConnection().prepareStatement(deleteQuery);

            ps.setInt(1, lawyerId);

            return (ps.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(P_LAWYER.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    // create a function to return an arraylist of lawyers
    public ArrayList<P_LAWYER> lawyersList(){
    
        ArrayList<P_LAWYER> list = new ArrayList<>();
        
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `lawyer`";
       
        try {
            st = DBMS.getConnection().createStatement();
            rs = st.executeQuery(selectQuery);
        
            P_LAWYER lawyer;
            
            while (rs.next()) {
               
                lawyer = new P_LAWYER(rs.getInt(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getString(4),
                                    rs.getString(5),
                                    rs.getString(6));
                
                list.add(lawyer);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(P_LAWYER.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return list;
    
    }
 
}
